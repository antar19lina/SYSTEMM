import LoginPage from "@/app/login/page"

export default function Home() {
  return <LoginPage />
}

